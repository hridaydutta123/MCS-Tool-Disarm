## Build for production

Require `node`, and `grunt`. Run

    npm install
    grunt

and find the app in the `production` folder. Run

    grunt deploy

To push the files to `timc.idv.tw` hosting.
